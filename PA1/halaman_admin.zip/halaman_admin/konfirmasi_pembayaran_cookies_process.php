<?php

    require '../config.php';

    $id = $_POST['id'];
    $email = $_POST['email'];
    $data = "UPDATE checkout_produk SET status_bayar = 'Terkonfirmasi' WHERE id_checkout = '$id'";

    if(mysqli_query($conn, $data)) {
        header("Location: cookies_konfirmasi.php");
    } else {
        echo "konfirmasi pembayaran produk gagal : " . mysqll_error($conn);
    }
?>